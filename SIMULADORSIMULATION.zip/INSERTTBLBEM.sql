INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 1, 'BUS', 1 );
INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 2, 'MERCEDEZ', 1 );
INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 3, 'NON-DC CV', 1 );
INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 4, 'OTHERS', 1 );
INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 5, 'TRUCK', 1 );
INSERT INTO SimulationMotor.dbo.tblbem
	( codbem, dsbem, dsstatus) VALUES ( 6, 'VAN', 1 );

