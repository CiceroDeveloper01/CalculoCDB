INSERT INTO SimulationMotor.dbo.tblrating
	( codrating, dsrating, dsstatus) VALUES ( 1, 'AA', 1 );
INSERT INTO SimulationMotor.dbo.tblrating
	( codrating, dsrating, dsstatus) VALUES ( 2, 'A', 1 );
INSERT INTO SimulationMotor.dbo.tblrating
	( codrating, dsrating, dsstatus) VALUES ( 3, 'B', 1 );
INSERT INTO SimulationMotor.dbo.tblrating
	( codrating, dsrating, dsstatus) VALUES ( 4, 'C', 1 );
INSERT INTO SimulationMotor.dbo.tblrating
	( codrating, dsrating, dsstatus) VALUES ( 5, 'D', 1 );

