INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 1, 2, 23.1000, 1 );
INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 2, 6, 19.2000, 1 );
INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 3, 5, 17.1000, 1 );
INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 4, 1, 15.4000, 1 );
INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 5, 3, null, 1 );
INSERT INTO SimulationMotor.dbo.tblbemmetarorac
	( codbemmetarorac, codbem, metarorac, dsstatus) VALUES ( 6, 4, null, 1 );
GO