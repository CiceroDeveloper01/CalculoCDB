INSERT INTO SimulationMotor.dbo.tblsegmento
	( codsegmento, dssegmento, dsstatus) VALUES ( 1, 'RETAIL', 1 );
INSERT INTO SimulationMotor.dbo.tblsegmento
	( codsegmento, dssegmento, dsstatus) VALUES ( 2, 'MIDDLE', 1 );
INSERT INTO SimulationMotor.dbo.tblsegmento
	( codsegmento, dssegmento, dsstatus) VALUES ( 3, 'KEY', 1 );
GO