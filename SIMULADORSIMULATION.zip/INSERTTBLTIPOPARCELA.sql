INSERT INTO SimulationMotor.dbo.tbltipoparcela
	( codtipoparcela, dstipoparcela, dsstatus) VALUES ( 1, 'Substituir a Parcela', 1 );
INSERT INTO SimulationMotor.dbo.tbltipoparcela
	( codtipoparcela, dstipoparcela, dsstatus) VALUES ( 2, 'Somar a Parcela', 1 );
GO