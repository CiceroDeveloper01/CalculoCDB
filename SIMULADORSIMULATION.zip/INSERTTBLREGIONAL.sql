INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 1, 'SP', 1 );
INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 2, 'DF', 1 );
INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 3, 'PA', 1 );
INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 4, 'RC', 1 );
INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 5, 'RJ', 1 );
INSERT INTO SimulationMotor.dbo.tblRegional
	( codregional, dsregional, dsstatus) VALUES ( 6, 'CEA', 1 );
GO