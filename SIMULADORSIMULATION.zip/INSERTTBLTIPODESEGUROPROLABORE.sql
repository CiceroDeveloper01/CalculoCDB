INSERT INTO SimulationMotor.dbo.tbltipodeseguroprolabore
	( codtipodeseguroprolabore, dstipodeseguro, vlprolabore) VALUES ( 1, 'Motor Insurance', 12.7200 );
INSERT INTO SimulationMotor.dbo.tbltipodeseguroprolabore
	( codtipodeseguroprolabore, dstipodeseguro, vlprolabore) VALUES ( 1, 'PPI', 62.9700 );
GO