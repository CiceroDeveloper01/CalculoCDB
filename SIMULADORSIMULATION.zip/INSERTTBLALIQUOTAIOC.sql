INSERT INTO SimulationMotor.dbo.tblaliquotaioc
	( codaliquotaioc, vlraliquotaioc, dsstatus) VALUES ( 1, 0.38, 1 );
GO