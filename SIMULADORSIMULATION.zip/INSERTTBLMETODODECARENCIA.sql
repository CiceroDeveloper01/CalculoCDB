INSERT INTO SimulationMotor.dbo.tblmetododecarencia
	( codmetododecarencia, dsmetododecarencia, dssatus) VALUES ( 1, 'em meses', 1 );
INSERT INTO SimulationMotor.dbo.tblmetododecarencia
	( codmetododecarencia, dsmetododecarencia, dssatus) VALUES ( 2, 'definir 1º vencimento', 1 );
GO