INSERT INTO SimulationMotor.dbo.tblspreadminimo
	( codspreadminimo, vlrspreadminimo, dsstatus) VALUES ( 1, 0.07, 1 );
GO